import 'package:equatable/equatable.dart';

class ImageProgress extends Equatable {
  final dynamic progress;
  final String? progressImageUrl;
  final dynamic response;
  const ImageProgress({
    required this.progress,
    this.progressImageUrl,
    required this.response,
  });
  ImageProgress copyWith({
    dynamic progress,
    String? progressImageUrl,
    dynamic response,
  }) {
    return ImageProgress(
      progress: progress ?? this.progress,
      progressImageUrl: progressImageUrl ?? this.progressImageUrl,
      response: response ?? this.response,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'progress': progress,
      'progressImageUrl': progressImageUrl,
      'response': response,
    };
  }

  factory ImageProgress.fromMap(Map<String, dynamic> map) {
    return ImageProgress(
      progress: map['progress'],
      progressImageUrl: map['progressImageUrl'],
      response: map['response'],
    );
  }
  Map<String, dynamic> toJson() {
    return {
      'progress': progress,
      'progressImageUrl': progressImageUrl,
      'response': response,
    };
  }

  factory ImageProgress.fromJson(Map<String, dynamic> json) {
    return ImageProgress(
      progress: json['progress'] as dynamic,
      progressImageUrl: json['progressImageUrl'] as String?,
      response: json['response'] as dynamic,
    );
  }
  @override
  List<Object?> get props => [
        progress,
        progressImageUrl,
        response,
      ];
}
