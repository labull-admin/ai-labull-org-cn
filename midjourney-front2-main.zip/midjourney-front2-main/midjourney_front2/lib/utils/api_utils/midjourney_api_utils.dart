import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:midjourneycn/models/image_progress.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

String? nextlegApiV2Message =
    dotenv.maybeGet('NEXTLEG_API_V2_MESSAGE', fallback: null);
String? nextLegAuthToken =
    dotenv.maybeGet('NEXTLEG_AUTH_TOKEN', fallback: null);

Future<ImageProgress> fetchImageProcessingStatus(
    {required String midjourneyInitialResponseMessageId}) async {
  try {
    assert(nextlegApiV2Message != null,
        'NEXTLEG_API_V2_MESSAGE env variable is null or not found');
    assert(nextLegAuthToken != null,
        'NEXTLEG_AUTH_TOKEN env variable is null or not found');
    print(
        "$nextlegApiV2Message$midjourneyInitialResponseMessageId?expireMins=2");
    print(nextLegAuthToken);
    final response = await http.get(
      Uri.parse(
          "$nextlegApiV2Message$midjourneyInitialResponseMessageId?expireMins=2"),
      headers: {
        'Authorization': 'Bearer $nextLegAuthToken',
      },
    );
    if (response.statusCode == 200) {
      final data = jsonDecode(utf8.decode(response.bodyBytes));
      return ImageProgress.fromJson(data);
    } else {
      throw Exception(
          'Failed to fetch image processing status with response status: ${response.statusCode}');
    }
  } catch (e) {
    print(e);
    throw Exception('fetchImageProcessingStatus failed: $e');
  }
}
