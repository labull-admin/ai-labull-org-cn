part of 'image_generation_tasks_bloc.dart';

sealed class ImageGenerationTasksEvent extends Equatable {
  final User user;
  const ImageGenerationTasksEvent({required this.user});

  @override
  List<Object?> get props => [];
}

class ImageGenerationTasksCreateTaskEvent extends ImageGenerationTasksEvent {
  final String content;
  const ImageGenerationTasksCreateTaskEvent(
      {required User user, required this.content})
      : super(user: user);

  @override
  List<Object> get props => [user];
}

class ImageGenerationTasksFetchNextPageOfTasksEvent
    extends ImageGenerationTasksEvent {
  const ImageGenerationTasksFetchNextPageOfTasksEvent({required User user})
      : super(user: user);

  @override
  List<Object> get props => [user];
}
