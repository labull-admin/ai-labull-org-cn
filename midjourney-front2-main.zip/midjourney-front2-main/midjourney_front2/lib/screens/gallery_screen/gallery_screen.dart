import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:midjourneycn/blocs/bloc_exports.dart';
import 'package:midjourneycn/models/user.dart';
import 'package:gallery_image_viewer/gallery_image_viewer.dart';

class GalleryScreen extends StatefulWidget {
  const GalleryScreen({super.key});

  @override
  State<GalleryScreen> createState() => _GalleryScreenState();
}

class _GalleryScreenState extends State<GalleryScreen> {
  List<ImageProvider?> _imageProviders = [];

  @override
  void initState() {
    super.initState();
    _loadAllImageGenerationTasks();
  }

  void _loadAllImageGenerationTasks() {
    User user = context.read<AuthBloc>().state.user!;
    context
        .read<ImageGenerationTasksBloc>()
        .add(ImageGenerationTasksFetchNextPageOfTasksEvent(user: user));
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ImageGenerationTasksBloc, ImageGenerationTasksState>(
        builder: (context, state) {
      if (state is ImageGenerationTasksUpdateSuccessState &&
          state.imageGenerationTasks.isNotEmpty) {
        _imageProviders = state.imageGenerationTasks.map((e) {
          return e.imagesSavedFromMidjourneyResponseSerialized != null
              ? CachedNetworkImageProvider(
                  e.imagesSavedFromMidjourneyResponseSerialized!.mainImage)
              : null;
        }).toList();
      }
      return Scaffold(
        body: Container(
          alignment: Alignment.center,
          child: GalleryImageView(
            listImage: _imageProviders
                .map((provider) =>
                    provider ??
                    const AssetImage('assets/images/cute_bunny.jpg'))
                .toList(),
            width: 600,
            height: 600,
            imageDecoration:
                BoxDecoration(border: Border.all(color: Colors.white)),
          ),
        ),
      );
    });
  }
}
