const String initialPlaceHolderImageUrl =
    "https://previews.123rf.com/images/kchung/kchung1610/kchung161001354/64508202-test-written-by-hand-hand-writing-on-transparent-board-photo.jpg";
