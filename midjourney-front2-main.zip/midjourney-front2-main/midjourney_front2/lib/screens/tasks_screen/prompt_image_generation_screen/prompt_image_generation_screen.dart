import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:midjourneycn/blocs/bloc_exports.dart';
import 'package:midjourneycn/models/image_generation_tasks.dart';
import 'package:midjourneycn/models/image_progress.dart';
import 'package:midjourneycn/models/image_progress_status.dart';
import 'package:midjourneycn/screens/tasks_screen/prompt_image_generation_screen/utils/consts.dart';
import 'package:midjourneycn/utils/api_utils/midjourney_api_utils.dart';
import 'package:midjourneycn/utils/api_utils/webhook_api_utils.dart';

class PromptImageGenerationScreen extends StatefulWidget {
  const PromptImageGenerationScreen({Key? key}) : super(key: key);

  @override
  State<PromptImageGenerationScreen> createState() =>
      _PromptImageGenerationScreenState();
}

class _PromptImageGenerationScreenState
    extends State<PromptImageGenerationScreen>
    with SingleTickerProviderStateMixin {
  String _placeholderImageUrl = initialPlaceHolderImageUrl;
  String _imageUrlInCachedNetworkImage = initialPlaceHolderImageUrl;
  String _myImageProgressStatus = ImageProcessStatus.notStarted;
  late ImageProgress _myImageProgress;
  int _fakeProgress = 0;

  @override
  void initState() {
    super.initState();
  }

  void startImageProcess(
      {required String midjourneyInitialResponseMessageId}) async {
    try {
      do {
        ImageProgress imageProgress = await fetchImageProcessingStatus(
            midjourneyInitialResponseMessageId:
                midjourneyInitialResponseMessageId);
        if (imageProgress.progress is String) {
          setState(() {
            _myImageProgressStatus = ImageProcessStatus.failed;
            _myImageProgress = imageProgress;
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content: Text('Image Process Status incomplete'),
              duration: Duration(seconds: 4),
            ));
          });
        } else if (imageProgress.progress is int &&
            imageProgress.progress == 0) {
          // fake progress add 1
          _fakeProgress += 1;
          setState(() {
            _myImageProgressStatus = ImageProcessStatus.initializing;
            _myImageProgress = imageProgress;
          });
        } else if (imageProgress.progress is int &&
            imageProgress.progress < 100) {
          setState(() {
            _myImageProgressStatus = ImageProcessStatus.progressing;
            _myImageProgress = imageProgress;
            _placeholderImageUrl = _imageUrlInCachedNetworkImage;
            _imageUrlInCachedNetworkImage =
                imageProgress.progressImageUrl as String;
          });
        } else {
          setState(() {
            _myImageProgressStatus = ImageProcessStatus.successful;
            _myImageProgress = imageProgress;
            _placeholderImageUrl = _imageUrlInCachedNetworkImage;
            _imageUrlInCachedNetworkImage = imageProgress.response['imageUrl'];
          });
        }
        await Future.delayed(const Duration(seconds: 2));
      } while (
          _myImageProgress.progress is int && _myImageProgress.progress < 100);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('startImageProcess error: ${e.toString()}'),
        duration: const Duration(seconds: 4),
      ));
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    final minDimension =
        screenWidth < screenHeight ? screenWidth : screenHeight;
    final desiredWidth = minDimension * 0.60;
    final desiredHeight = minDimension * 0.85;

    return Scaffold(
      body: SingleChildScrollView(
        child: Stack(
          children: [
            Container(
              alignment: Alignment.center,
              child: SizedBox(
                width: desiredWidth,
                height: desiredHeight,
                child: Column(
                  children: [
                    if (_myImageProgressStatus ==
                        ImageProcessStatus.initializing)
                      LinearProgressIndicator(
                        value: _fakeProgress / 100,
                      )
                    else if (_myImageProgressStatus ==
                        ImageProcessStatus.progressing)
                      LinearProgressIndicator(
                        value: _myImageProgress.progress / 100,
                      ),
                    CachedNetworkImage(
                      imageUrl: _imageUrlInCachedNetworkImage ==
                              initialPlaceHolderImageUrl
                          ? _imageUrlInCachedNetworkImage
                          : "$proxyFetchImageBackApiUrl$_imageUrlInCachedNetworkImage",
                      errorWidget: (context, url, error) =>
                          const Icon(Icons.error),
                      progressIndicatorBuilder:
                          (context, url, downloadProgress) {
                        return Stack(
                          children: [
                            CachedNetworkImage(
                              imageUrl: _placeholderImageUrl ==
                                      initialPlaceHolderImageUrl
                                  ? _placeholderImageUrl
                                  : "$proxyFetchImageBackApiUrl$_placeholderImageUrl",
                              progressIndicatorBuilder:
                                  (context, url, progress) {
                                return CircularProgressIndicator(
                                  value: progress.progress,
                                );
                              },
                            ),
                            if (_myImageProgressStatus ==
                                    ImageProcessStatus.successful &&
                                downloadProgress.progress is double)
                              Center(
                                child: Text(
                                  "${(downloadProgress.progress! * 100).round()}%",
                                  style: const TextStyle(
                                      color: Colors.white, fontSize: 20),
                                ),
                              ),
                          ],
                        );
                      },
                    ),
                    if (_myImageProgressStatus == ImageProcessStatus.successful)
                      Text(_myImageProgress.response['content'])
                  ],
                ),
              ),
            ),
            Container(
              alignment: Alignment.topRight,
              padding: const EdgeInsets.only(right: 16),
              child: Column(
                children: [
                  FloatingActionButton(
                      onPressed: () async {
                        String? myMidjourneyInitialResponseMessageId =
                            await showAlert(context);
                        if (myMidjourneyInitialResponseMessageId != null) {
                          //set fake progress to 0
                          _fakeProgress = 0;
                          // start progress
                          startImageProcess(
                              midjourneyInitialResponseMessageId:
                                  myMidjourneyInitialResponseMessageId);
                        }
                      },
                      child: const Icon(Icons.new_label)),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Future<String?> showAlert(BuildContext context) async {
    String? result = await showDialog<String>(
      context: context,
      builder: (BuildContext context) {
        String content = "";
        return AlertDialog(
          title: const Text('Title'),
          content: TextField(
            autofocus: true,
            decoration: const InputDecoration(
              labelText: 'Enter text',
            ),
            onChanged: (value) {
              content = value;
            },
          ),
          actions: <Widget>[
            TextButton(
              child: Text('CANCEL'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              onPressed: () async {
                try {
                  if (content.isEmpty) throw Exception('content is empty');
                  ImageGenerationTask imageGenerationTask =
                      await createImageGenerationTask(
                          userJwtAccessToken: context
                              .read<AuthBloc>()
                              .state
                              .user!
                              .jwtAccessToken!,
                          content: content);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Successful'),
                      duration: const Duration(seconds: 4),
                    ),
                  );
                  Navigator.of(context).pop(
                      imageGenerationTask.midjourneyInitialResponseMessageId);
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                          'Failed to create ImageGenerationTask with error: ${e.toString()}'),
                      duration: const Duration(seconds: 4),
                    ),
                  );
                }
              },
              child: const Text('OK'),
            )
          ],
        );
      },
    );
    return result;
  }
}
