import 'package:flutter/material.dart';
import 'package:midjourneycn/screens/main_screen.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter/foundation.dart';
import './blocs/bloc_exports.dart';
import 'package:midjourneycn/.env/env.dart'
    show CURRENT_STAGE, DEV_STAGE, PROD_STAGE;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // save common env variables as a Map<String, String>
  await dotenv.load(fileName: "lib/.env/.env.common");
  Map<String, String> envVars = Map.from(dotenv.env);
  if (CURRENT_STAGE == PROD_STAGE) {
    await dotenv.load(fileName: "lib/.env/.env.prod", mergeWith: envVars);
  } else if (CURRENT_STAGE == DEV_STAGE) {
    await dotenv.load(fileName: "lib/.env/.env.dev", mergeWith: envVars);
  } else {
    throw Exception(
        'CURRENT_STAGE env variable is not set to either $DEV_STAGE or $PROD_STAGE');
  }

  final storage = await HydratedStorage.build(
    storageDirectory: await getApplicationDocumentsDirectory(),
  );
  HydratedBloc.storage = storage;
  Bloc.observer = AppBlocObserver();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(providers: [
      BlocProvider<AuthBloc>(
        create: (context) => AuthBloc(),
      ),
      BlocProvider<ImageGenerationTasksBloc>(
          create: (context) => ImageGenerationTasksBloc()),
      // add more bloc providers here as needed
    ], child: const MainScreen());
  }
}
