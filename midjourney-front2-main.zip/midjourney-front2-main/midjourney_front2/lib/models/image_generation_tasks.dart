import 'package:equatable/equatable.dart';
import 'package:midjourneycn/models/images_saved_from_midjourney_response.dart';

class ImageGenerationTask extends Equatable {
  final int pk;
  final String status;
  final String statusMessage;
  final int midjourneyInitialResponse;
  final String midjourneyInitialResponseMessageId;
  final bool isMidjourneyInitialResponseSuccessful;
  final int? midJourneyResponseToWebhook;
  final bool? isMidJourneyResponseToWebhookSuccessful;
  final int? imagesSavedFromMidjourneyResponse;
  final ImagesSavedFromMidjourneyResponse?
      imagesSavedFromMidjourneyResponseSerialized;
  final bool? isImagesSavedFromMidjourneyResponseSuccessful;
  final int user;
  final String created_at;
  final String updated_at;

  const ImageGenerationTask({
    required this.pk,
    required this.status,
    required this.statusMessage,
    required this.midjourneyInitialResponse,
    required this.midjourneyInitialResponseMessageId,
    required this.isMidjourneyInitialResponseSuccessful,
    this.midJourneyResponseToWebhook,
    this.isMidJourneyResponseToWebhookSuccessful,
    this.imagesSavedFromMidjourneyResponse,
    this.imagesSavedFromMidjourneyResponseSerialized,
    this.isImagesSavedFromMidjourneyResponseSuccessful,
    required this.user,
    required this.created_at,
    required this.updated_at,
  });

  ImageGenerationTask copyWith({
    int? pk,
    String? status,
    String? statusMessage,
    int? midjourneyInitialResponse,
    String? midjourneyInitialResponseMessageId,
    bool? isMidjourneyInitialResponseSuccessful,
    int? midJourneyResponseToWebhook,
    bool? isMidJourneyResponseToWebhookSuccessful,
    int? imagesSavedFromMidjourneyResponse,
    ImagesSavedFromMidjourneyResponse?
        imagesSavedFromMidjourneyResponseSerialized,
    bool? isImagesSavedFromMidjourneyResponseSuccessful,
    int? user,
    String? created_at,
    String? updated_at,
  }) {
    return ImageGenerationTask(
      pk: pk ?? this.pk,
      status: status ?? this.status,
      statusMessage: statusMessage ?? this.statusMessage,
      midjourneyInitialResponse:
          midjourneyInitialResponse ?? this.midjourneyInitialResponse,
      midjourneyInitialResponseMessageId: midjourneyInitialResponseMessageId ??
          this.midjourneyInitialResponseMessageId,
      isMidjourneyInitialResponseSuccessful:
          isMidjourneyInitialResponseSuccessful ??
              this.isMidjourneyInitialResponseSuccessful,
      midJourneyResponseToWebhook:
          midJourneyResponseToWebhook ?? this.midJourneyResponseToWebhook,
      isMidJourneyResponseToWebhookSuccessful:
          isMidJourneyResponseToWebhookSuccessful ??
              this.isMidJourneyResponseToWebhookSuccessful,
      imagesSavedFromMidjourneyResponse: imagesSavedFromMidjourneyResponse ??
          this.imagesSavedFromMidjourneyResponse,
      imagesSavedFromMidjourneyResponseSerialized:
          imagesSavedFromMidjourneyResponseSerialized ??
              this.imagesSavedFromMidjourneyResponseSerialized,
      isImagesSavedFromMidjourneyResponseSuccessful:
          isImagesSavedFromMidjourneyResponseSuccessful ??
              this.isImagesSavedFromMidjourneyResponseSuccessful,
      user: user ?? this.user,
      created_at: created_at ?? this.created_at,
      updated_at: updated_at ?? this.updated_at,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'pk': pk,
      'status': status,
      'statusMessage': statusMessage,
      'midjourneyInitialResponse': midjourneyInitialResponse,
      'midjourneyInitialResponseMessageId': midjourneyInitialResponseMessageId,
      'isMidjourneyInitialResponseSuccessful':
          isMidjourneyInitialResponseSuccessful,
      'midJourneyResponseToWebhook': midJourneyResponseToWebhook,
      'isMidJourneyResponseToWebhookSuccessful':
          isMidJourneyResponseToWebhookSuccessful,
      'imagesSavedFromMidjourneyResponse': imagesSavedFromMidjourneyResponse,
      'imagesSavedFromMidjourneyResponseSerialized':
          imagesSavedFromMidjourneyResponseSerialized,
      'isImagesSavedFromMidjourneyResponseSuccessful':
          isImagesSavedFromMidjourneyResponseSuccessful,
      'user': user,
      'created_at': created_at,
      'updated_at': updated_at,
    };
  }

  factory ImageGenerationTask.fromMap(Map<String, dynamic> map) {
    return ImageGenerationTask(
      pk: map['pk'] as int,
      status: map['status'] as String,
      statusMessage: map['statusMessage'] as String,
      midjourneyInitialResponse: map['midjourneyInitialResponse'] as int,
      midjourneyInitialResponseMessageId:
          map['midjourneyInitialResponseMessageId'] as String,
      isMidjourneyInitialResponseSuccessful:
          map['isMidjourneyInitialResponseSuccessful'] as bool,
      midJourneyResponseToWebhook: map['midJourneyResponseToWebhook'] as int?,
      isMidJourneyResponseToWebhookSuccessful:
          map['isMidJourneyResponseToWebhookSuccessful'] as bool?,
      imagesSavedFromMidjourneyResponse:
          map['imagesSavedFromMidjourneyResponse'] as int?,
      imagesSavedFromMidjourneyResponseSerialized:
          map['imagesSavedFromMidjourneyResponseSerialized']
              as ImagesSavedFromMidjourneyResponse?,
      isImagesSavedFromMidjourneyResponseSuccessful:
          map['isImagesSavedFromMidjourneyResponseSuccessful'] as bool?,
      user: map['user'] as int,
      created_at: map['created_at'] as String,
      updated_at: map['updated_at'] as String,
    );
  }
  Map<String, dynamic> toJson() {
    return {
      'pk': pk,
      'status': status,
      'statusMessage': statusMessage,
      'midjourneyInitialResponse': midjourneyInitialResponse,
      'midjourneyInitialResponseMessageId': midjourneyInitialResponseMessageId,
      'isMidjourneyInitialResponseSuccessful':
          isMidjourneyInitialResponseSuccessful,
      'midJourneyResponseToWebhook': midJourneyResponseToWebhook,
      'isMidJourneyResponseToWebhookSuccessful':
          isMidJourneyResponseToWebhookSuccessful,
      'imagesSavedFromMidjourneyResponse': imagesSavedFromMidjourneyResponse,
      'imagesSavedFromMidjourneyResponseSerialized':
          imagesSavedFromMidjourneyResponseSerialized,
      'isImagesSavedFromMidjourneyResponseSuccessful':
          isImagesSavedFromMidjourneyResponseSuccessful,
      'user': user,
      'created_at': created_at,
      'updated_at': updated_at,
    };
  }

  factory ImageGenerationTask.fromJson(Map<String, dynamic> json) {
    return ImageGenerationTask(
      pk: json['pk'] as int,
      status: json['status'] as String,
      statusMessage: json['statusMessage'] as String,
      midjourneyInitialResponse: json['midjourneyInitialResponse'] as int,
      midjourneyInitialResponseMessageId:
          json['midjourneyInitialResponseMessageId'] as String,
      isMidjourneyInitialResponseSuccessful:
          json['isMidjourneyInitialResponseSuccessful'] as bool,
      midJourneyResponseToWebhook: json['midJourneyResponseToWebhook'] as int?,
      isMidJourneyResponseToWebhookSuccessful:
          json['isMidJourneyResponseToWebhookSuccessful'] as bool?,
      imagesSavedFromMidjourneyResponse:
          json['imagesSavedFromMidjourneyResponse'] as int?,
      imagesSavedFromMidjourneyResponseSerialized:
          json['imagesSavedFromMidjourneyResponseSerialized']
              as ImagesSavedFromMidjourneyResponse?,
      isImagesSavedFromMidjourneyResponseSuccessful:
          json['isImagesSavedFromMidjourneyResponseSuccessful'] as bool?,
      user: json['user'] as int,
      created_at: json['created_at'] as String,
      updated_at: json['updated_at'] as String,
    );
  }
  @override
  List<Object?> get props => [
        pk,
        status,
        statusMessage,
        midjourneyInitialResponse,
        midjourneyInitialResponseMessageId,
        isMidjourneyInitialResponseSuccessful,
        midJourneyResponseToWebhook,
        isMidJourneyResponseToWebhookSuccessful,
        imagesSavedFromMidjourneyResponse,
        imagesSavedFromMidjourneyResponseSerialized,
        isImagesSavedFromMidjourneyResponseSuccessful,
        user,
        created_at,
        updated_at,
      ];
}
