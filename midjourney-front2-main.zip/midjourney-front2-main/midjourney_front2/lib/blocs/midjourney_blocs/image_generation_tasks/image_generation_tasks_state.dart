part of 'image_generation_tasks_bloc.dart';

sealed class ImageGenerationTasksState extends Equatable {
  final List<ImageGenerationTask> imageGenerationTasks;

  final String? error;
  const ImageGenerationTasksState({
    required this.imageGenerationTasks,
    this.error,
  });

  @override
  List<Object?> get props => [
        imageGenerationTasks,
        error,
      ];
}

final class ImageGenerationTasksUpdateInitial
    extends ImageGenerationTasksState {
  const ImageGenerationTasksUpdateInitial(
      {required super.imageGenerationTasks});
  static Map<String, dynamic> toMap(ImageGenerationTasksUpdateInitial state) =>
      {
        'type': imageGenerationTasksUpdateInitialStateType,
      };
  static ImageGenerationTasksUpdateInitial fromMap(Map<String, dynamic> map) =>
      const ImageGenerationTasksUpdateInitial(imageGenerationTasks: []);
}

final class ImageGenerationTasksUpdateLoadingState
    extends ImageGenerationTasksState {
  const ImageGenerationTasksUpdateLoadingState(
      {required super.imageGenerationTasks});
  static Map<String, dynamic> toMap(
          ImageGenerationTasksUpdateLoadingState state) =>
      {
        'type': imageGenerationTasksUpdateLoadingStateType,
      };
  static ImageGenerationTasksUpdateLoadingState fromMap(
          Map<String, dynamic> map) =>
      const ImageGenerationTasksUpdateLoadingState(imageGenerationTasks: []);
}

final class ImageGenerationTasksUpdateSuccessState
    extends ImageGenerationTasksState {
  const ImageGenerationTasksUpdateSuccessState({
    required List<ImageGenerationTask> imageGenerationTasks,
  }) : super(
          imageGenerationTasks: imageGenerationTasks,
        );
  static Map<String, dynamic> toMap(
          ImageGenerationTasksUpdateSuccessState state) =>
      {
        'type': imageGenerationTasksUpdateSuccessStateType,
        'imageGenerationTasks': state.imageGenerationTasks,
      };
  static ImageGenerationTasksUpdateSuccessState fromMap(
          Map<String, dynamic> map) =>
      ImageGenerationTasksUpdateSuccessState(
          imageGenerationTasks: (map['imageGenerationTasks'] as List<dynamic>)
              .map((e) => ImageGenerationTask.fromJson(e))
              .toList());
}

final class ImageGenerationTasksUpdateFailureState
    extends ImageGenerationTasksState {
  const ImageGenerationTasksUpdateFailureState({
    required String error,
    required List<ImageGenerationTask> imageGenerationTasks,
  }) : super(
          imageGenerationTasks: imageGenerationTasks,
          error: error,
        );
  static Map<String, dynamic> toMap(
          ImageGenerationTasksUpdateFailureState state) =>
      {
        'type': imageGenerationTasksUpdateFailureStateType,
        'error': state.error,
      };
  static ImageGenerationTasksUpdateFailureState fromMap(
          Map<String, dynamic> map) =>
      ImageGenerationTasksUpdateFailureState(
          error: map['error'] as String, imageGenerationTasks: []);
}
