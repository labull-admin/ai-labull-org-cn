import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:midjourneycn/blocs/bloc_exports.dart';
import 'package:midjourneycn/utils/api_utils/webhook_api_utils.dart';
import '../../../models/user.dart';
import 'state_type.dart';

part 'auth_event.dart';
part 'auth_state.dart';

class AuthBloc extends HydratedBloc<AuthEvent, AuthState> {
  AuthBloc() : super(const AuthNotLogedInState()) {
    on<Login>(_onLogin);
    on<Logout>(_onLogout);
  }
  void _onLogin(Login event, Emitter<AuthState> emit) async {
    emit(AuthLoginInitialState(user: event.user!));

    try {
      if (event.user != null) {
        String jwtAccessToken = await login(
            username: event.user!.name, password: event.user!.password);
        emit(const AuthLoginSuccessState());
        emit(AuthLogedInState(
            user: event.user!.copyWith(jwtAccessToken: jwtAccessToken)));
        emit(AuthLogedInState(
            user: User(
                name: event.user!.name,
                password: event.user!.password,
                jwtAccessToken: jwtAccessToken)));
      } else {
        throw ("User name and password required");
      }
    } catch (e) {
      emit(AuthLoginFailureState(error: e.toString()));
      emit(const AuthNotLogedInState());
    }
  }

  void _onLogout(Logout event, Emitter<AuthState> emit) async {
    try {
      emit(const AuthLogoutInitialState());
      emit(const AuthLogoutLoadingState());
      emit(const AuthLogoutSuccessState());
      emit(const AuthNotLogedInState());
    } catch (e) {
      emit(AuthLogoutFailureState(error: e.toString()));
      emit(AuthLogedInState(user: event.user!));
    }
  }

  @override
  AuthState? fromJson(Map<String, dynamic> json) {
    String type = json['type'];
    switch (type) {
      case authNotLogedInStateType:
        return AuthNotLogedInState.fromMap(json);
      case authLogedInStateType:
        return AuthLogedInState.fromMap(json);
      case authLoginInitialStateType:
        return AuthLoginInitialState.fromMap(json);
      case authLoginLoadingStateType:
        return AuthLoginLoadingState.fromMap(json);
      case authLoginSuccessStateType:
        return AuthLoginSuccessState.fromMap(json);
      case authLoginFailureStateType:
        return AuthLoginFailureState.fromMap(json);
      case authLogoutInitialStateType:
        return AuthLogoutInitialState.fromMap(json);
      case authLogoutLoadingStateType:
        return AuthLogoutLoadingState.fromMap(json);
      case authLogoutSuccessStateType:
        return AuthLogoutSuccessState.fromMap(json);
      case authLogoutFailureStateType:
        return AuthLogoutFailureState.fromMap(json);
      // add cases for other state classes here
      default:
        throw UnimplementedError("$type fromJson is not implemented");
    }
  }

  @override
  Map<String, dynamic>? toJson(AuthState state) {
    // TODO: implement toJson
    switch (state.runtimeType) {
      case AuthNotLogedInState:
        return AuthNotLogedInState.toMap(state as AuthNotLogedInState);
      case AuthLogedInState:
        return AuthLogedInState.toMap(state as AuthLogedInState);
      case AuthLoginInitialState:
        return AuthLoginInitialState.toMap(state as AuthLoginInitialState);
      case AuthLoginLoadingState:
        return AuthLoginLoadingState.toMap(state as AuthLoginLoadingState);
      case AuthLoginSuccessState:
        return AuthLoginSuccessState.toMap(state as AuthLoginSuccessState);
      case AuthLoginFailureState:
        return AuthLoginFailureState.toMap(state as AuthLoginFailureState);
      case AuthLogoutInitialState:
        return AuthLogoutInitialState.toMap(state as AuthLogoutInitialState);
      case AuthLogoutLoadingState:
        return AuthLogoutLoadingState.toMap(state as AuthLogoutLoadingState);
      case AuthLogoutSuccessState:
        return AuthLogoutSuccessState.toMap(state as AuthLogoutSuccessState);
      case AuthLogoutFailureState:
        return AuthLogoutFailureState.toMap(state as AuthLogoutFailureState);
      // add cases for other state classes here
      default:
        throw UnimplementedError(
            "${state.runtimeType} fromJson is not implemented");
    }
  }
}
