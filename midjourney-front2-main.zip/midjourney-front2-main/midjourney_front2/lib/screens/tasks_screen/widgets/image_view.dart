import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:image_gallery_saver/image_gallery_saver.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:file_picker/file_picker.dart';
import 'package:photo_view/photo_view.dart';
import 'dart:io' as io;
import 'package:uuid/uuid.dart';

class ImageViewScreen extends StatelessWidget {
  final String imageUrl;

  const ImageViewScreen({Key? key, required this.imageUrl}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Image View'),
        actions: [
          IconButton(
              onPressed: () async {
                var file = await DefaultCacheManager().getSingleFile(imageUrl);

                if (io.Platform.isAndroid || io.Platform.isIOS) {
                  try {
                    final result = await ImageGallerySaver.saveImage(
                        await file.readAsBytes());
                    result['isSuccess']
                        ? ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                                content: Text('Image saved successfully!')))
                        : throw ('ImageGallerySaver saveImage failed');
                  } catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text('Failed to save image with error: $e')));
                  }
                } else if (io.Platform.isMacOS ||
                    io.Platform.isLinux ||
                    io.Platform.isWindows) {
                  String? outputFile = await FilePicker.platform.saveFile(
                    dialogTitle: 'Save Your File to desired location',
                    fileName: '${const Uuid().v4().substring(0, 5)}.jpg',
                  );

                  try {
                    if (outputFile != null) {
                      io.File returnedFile = io.File('$outputFile');
                      await returnedFile.writeAsBytes(await file.readAsBytes());
                      ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Image saved successfully!')));
                    } else {
                      throw ('outputFile is null');
                    }
                  } catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text('Failed to save image with error: $e')));
                  }
                }
              },
              icon: Icon(Icons.download))
        ],
      ),
      body: Center(
          child: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: PhotoView(
          imageProvider: CachedNetworkImageProvider(imageUrl),
          loadingBuilder: (context, event) => const Center(
            child: CircularProgressIndicator(),
          ),
          enableRotation: true,
          backgroundDecoration: const BoxDecoration(color: Colors.white),
        ),
      )),
    );
  }
}
