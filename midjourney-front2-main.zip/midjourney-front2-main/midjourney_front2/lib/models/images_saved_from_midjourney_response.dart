import 'package:equatable/equatable.dart';

class ImagesSavedFromMidjourneyResponse extends Equatable {
  final int pk;
  final String originatingMessageId;
  final String mainImage;
  final String? image0Url;
  final String? image1Url;
  final String? image2Url;
  final String? image3Url;
  final String created_at;
  final String updated_at;
  const ImagesSavedFromMidjourneyResponse({
    required this.pk,
    required this.originatingMessageId,
    required this.mainImage,
    this.image0Url,
    this.image1Url,
    this.image2Url,
    this.image3Url,
    required this.created_at,
    required this.updated_at,
  });
  ImagesSavedFromMidjourneyResponse copyWith({
    int? pk,
    String? originatingMessageId,
    String? mainImage,
    String? image0Url,
    String? image1Url,
    String? image2Url,
    String? image3Url,
    String? created_at,
    String? updated_at,
  }) {
    return ImagesSavedFromMidjourneyResponse(
      pk: pk ?? this.pk,
      originatingMessageId: originatingMessageId ?? this.originatingMessageId,
      mainImage: mainImage ?? this.mainImage,
      image0Url: image0Url ?? this.image0Url,
      image1Url: image1Url ?? this.image1Url,
      image2Url: image2Url ?? this.image2Url,
      image3Url: image3Url ?? this.image3Url,
      created_at: created_at ?? this.created_at,
      updated_at: updated_at ?? this.updated_at,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'pk': pk,
      'originatingMessageId': originatingMessageId,
      'mainImage': mainImage,
      'image0Url': image0Url,
      'image1Url': image1Url,
      'image2Url': image2Url,
      'image3Url': image3Url,
      'created_at': created_at,
      'updated_at': updated_at,
    };
  }

  factory ImagesSavedFromMidjourneyResponse.fromMap(Map<String, dynamic> map) {
    return ImagesSavedFromMidjourneyResponse(
      pk: map['pk'] as int,
      originatingMessageId: map['originatingMessageId'] as String,
      mainImage: map['mainImage'] as String,
      image0Url: map['image0Url'] as String?,
      image1Url: map['image1Url'] as String?,
      image2Url: map['image2Url'] as String?,
      image3Url: map['image3Url'] as String?,
      created_at: map['created_at'] as String,
      updated_at: map['updated_at'] as String,
    );
  }
  Map<String, dynamic> toJson() {
    return {
      'pk': pk,
      'originatingMessageId': originatingMessageId,
      'mainImage': mainImage,
      'image0Url': image0Url,
      'image1Url': image1Url,
      'image2Url': image2Url,
      'image3Url': image3Url,
      'created_at': created_at,
      'updated_at': updated_at,
    };
  }

  factory ImagesSavedFromMidjourneyResponse.fromJson(
      Map<String, dynamic> json) {
    return ImagesSavedFromMidjourneyResponse(
      pk: json['pk'] as int,
      originatingMessageId: json['originatingMessageId'] as String,
      mainImage: json['mainImage'] as String,
      image0Url: json['image0Url'] as String?,
      image1Url: json['image1Url'] as String?,
      image2Url: json['image2Url'] as String?,
      image3Url: json['image3Url'] as String?,
      created_at: json['created_at'] as String,
      updated_at: json['updated_at'] as String,
    );
  }
  @override
  List<Object?> get props => [
        pk,
        originatingMessageId,
        mainImage,
        image0Url,
        image1Url,
        image2Url,
        image3Url,
        created_at,
        updated_at,
      ];
}
