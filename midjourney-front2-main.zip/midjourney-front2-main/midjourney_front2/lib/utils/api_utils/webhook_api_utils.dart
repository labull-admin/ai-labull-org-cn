import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:midjourneycn/models/image_generation_tasks.dart';
import 'package:midjourneycn/models/images_saved_from_midjourney_response.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

String? midjourneyProxyServerBackendUrl =
    dotenv.maybeGet('MIDJOURNEY_PROXY_SERVER_BACKEND_URL', fallback: null);

String coreLoginApiUrl = "$midjourneyProxyServerBackendUrl/core/login/";

String midjourneyInitialResponseApiUrl =
    "$midjourneyProxyServerBackendUrl/midjourney/midjourneyinitialresponse/";

String midjourneyInitialResponseImagineApiUrl =
    "$midjourneyProxyServerBackendUrl/midjourney/midjourneyinitialresponseimagine/";

String midjourneyInitialResponseButtonsApiUrl =
    "$midjourneyProxyServerBackendUrl/midjourney/midjourneyinitialresponsebuttons/";

String imageGenerationTaskApiUrl =
    "$midjourneyProxyServerBackendUrl/midjourney/imagegenerationtask/";
String imageGenerationTaskLatestApiUrl =
    "$midjourneyProxyServerBackendUrl/midjourney/imagegenerationtask/latest";

String midjourneyResponseToWebhookApiUrl =
    "$midjourneyProxyServerBackendUrl/midjourney/midjourneyresponsetowebhook/";

String imagessavedFromMidjourneyResponseApiUrl =
    "$midjourneyProxyServerBackendUrl/midjourney/imagessavedfrommidjourneyresponse/";

String proxyFetchImageBackApiUrl =
    "$midjourneyProxyServerBackendUrl/fetch-image/?url=";

Future<String> login(
    {required String username, required String password}) async {
  try {
    final response = await http.post(
      Uri.parse(coreLoginApiUrl),
      body: {
        'username': username,
        'password': password,
      },
    );
    final data = jsonDecode(utf8.decode(response.bodyBytes));
    if (response.statusCode == 200) {
      return data['access'];
    } else {
      String errorMessage =
          'Failed to login: response status code is ${response.statusCode}';
      data.containsKey('detail')
          ? errorMessage += ': ${data['detail']}'
          : errorMessage;
      throw Exception(errorMessage);
    }
  } catch (e) {
    throw ('login error: $e');
  }
}

//fetch the latest ImageGenerationTask
Future<ImageGenerationTask> fetchTheLatestImageGenerationTask(
    {required String userJwtAccessToken}) async {
  try {
    final response = await http.get(
      Uri.parse(imageGenerationTaskLatestApiUrl),
      headers: {
        'Authorization': 'JWT $userJwtAccessToken',
      },
    );
    final data = jsonDecode(utf8.decode(response.bodyBytes));

    if (response.statusCode == 200) {
      ImageGenerationTask imageGenerationTask =
          ImageGenerationTask.fromJson(data);
      return imageGenerationTask;
    } else {
      String errorMessage =
          'Failed to fetch the latest ImageGenerationTask: response status code is ${response.statusCode}';
      data.containsKey('detail')
          ? errorMessage += ': ${data['detail']}'
          : errorMessage;
      throw Exception(errorMessage);
    }
  } catch (e) {
    throw ("fetchTheLatestImageGenerationTask error: $e");
  }
}

//fetch the next page of ImageGenerationTasks
Future<List<ImageGenerationTask>> fetchThePageOfImageGenerationTasks(
    {required String userJwtAccessToken, required int pageToLoad}) async {
  try {
    final response = await http.get(
      Uri.parse('$imageGenerationTaskApiUrl?page=$pageToLoad'),
      headers: {
        'Authorization': 'JWT $userJwtAccessToken',
      },
    );
    final data = jsonDecode(utf8.decode(response.bodyBytes));

    if (response.statusCode == 200) {
      List<ImageGenerationTask> imageGenerationTasks =
          List<ImageGenerationTask>.from(data['results'].map((data) {
        ImagesSavedFromMidjourneyResponse?
            imagesSavedFromMidjourneyResponseSerialized;
        if (data['imagesSavedFromMidjourneyResponseSerialized'] != null) {
          imagesSavedFromMidjourneyResponseSerialized =
              ImagesSavedFromMidjourneyResponse.fromJson(
                  data['imagesSavedFromMidjourneyResponseSerialized']);
        }

        data.remove('imagesSavedFromMidjourneyResponseSerialized');
        return ImageGenerationTask.fromJson({
          ...data,
          'imagesSavedFromMidjourneyResponseSerialized':
              imagesSavedFromMidjourneyResponseSerialized
        });
      }));

      return imageGenerationTasks;
    } else {
      String errorMessage =
          'Failed to fetch the next page of ImageGenerationTasks: response status code is ${response.statusCode}';
      data.containsKey('detail')
          ? errorMessage += ': ${data['detail']}'
          : errorMessage;
      throw Exception(errorMessage);
    }
  } catch (e) {
    throw ("fetchNextPageOfImageGenerationTasks error: $e");
  }
}

//post midjourneyImagineApi
Future<ImageGenerationTask> createImageGenerationTask(
    {required String userJwtAccessToken, required String content}) async {
  try {
    final response = await http.post(
      Uri.parse(midjourneyInitialResponseImagineApiUrl),
      headers: {
        'Authorization': 'JWT $userJwtAccessToken',
      },
      body: {
        'content': content,
      },
    );
    final data = jsonDecode(utf8.decode(response.bodyBytes));
    if (response.statusCode == 201) {
      return fetchTheImageGenerationTask(
          userJwtAccessToken: userJwtAccessToken,
          imageGenerationTaskPk: data['imageGenerationTask']);
    } else {
      String errorMessage =
          'Failed to post midjourneyImagineApi: response status code is ${response.statusCode}';
      data.containsKey('detail')
          ? errorMessage += ': ${data['detail']}'
          : errorMessage;
      throw Exception(errorMessage);
    }
  } catch (e) {
    throw ('postMidjourneyImagineApi error: $e');
  }
}

//fetch all ImageGenerationTasks
Future<List<ImageGenerationTask>> fetchAllImageGenerationTasks(
    {required String userJwtAccessToken}) async {
  try {
    final response = await http.get(
      Uri.parse(imageGenerationTaskApiUrl),
      headers: {
        'Authorization': 'JWT $userJwtAccessToken',
      },
    );
    final data = jsonDecode(utf8.decode(response.bodyBytes));

    if (response.statusCode == 200) {
      List<ImageGenerationTask> imageGenerationTasks =
          List<ImageGenerationTask>.from(
              data.map((data) => ImageGenerationTask.fromJson(data)));

      return imageGenerationTasks;
    } else {
      String errorMessage =
          'Failed to load tasks: response status code is ${response.statusCode}';
      data.containsKey('detail')
          ? errorMessage += ': ${data['detail']}'
          : errorMessage;
      throw Exception(errorMessage);
    }
  } catch (e) {
    throw ("fetchAllImageGenerationTasks error: $e");
  }
}

//delete the ImageGenerationTask
Future<ImageGenerationTask> fetchTheImageGenerationTask(
    {required String userJwtAccessToken,
    required int imageGenerationTaskPk}) async {
  try {
    final response = await http.get(
      Uri.parse('$imageGenerationTaskApiUrl$imageGenerationTaskPk/'),
      headers: {
        'Authorization': 'JWT $userJwtAccessToken',
      },
    );
    final data = jsonDecode(utf8.decode(response.bodyBytes));
    if (response.statusCode == 200) {
      ImageGenerationTask theImageGenerationTask =
          ImageGenerationTask.fromJson(data);

      return theImageGenerationTask;
    } else {
      String errorMessage =
          'Failed to fetch the task: response status code is ${response.statusCode}';
      data.containsKey('detail')
          ? errorMessage += ': ${data['detail']}'
          : errorMessage;
      throw Exception(errorMessage);
    }
  } catch (e) {
    throw ('fetchTheImageGenerationTask error: $e');
  }
}

//fetch the ImageGenerationTask
Future<ImagesSavedFromMidjourneyResponse>
    fetchTheImagesSavedFromMidjourneyResponse(
        {required String userJwtAccessToken,
        required int imagesSavedFromMidjourneyResponsePk}) async {
  try {
    final response = await http.get(
      Uri.parse(
          "$imagessavedFromMidjourneyResponseApiUrl${imagesSavedFromMidjourneyResponsePk.toString()}/"),
      headers: {
        'Authorization': 'JWT $userJwtAccessToken',
      },
    );
    final data = jsonDecode(utf8.decode(response.bodyBytes));

    if (response.statusCode == 200) {
      ImagesSavedFromMidjourneyResponse imagesSavedFromMidjourneyResponse =
          ImagesSavedFromMidjourneyResponse.fromJson(data);
      return imagesSavedFromMidjourneyResponse;
    } else {
      String errorMessage =
          'Failed to fetch the ImageGenerationTask: response status code is ${response.statusCode}';
      data.containsKey('detail')
          ? errorMessage += ': ${data['detail']}'
          : errorMessage;
      throw Exception(errorMessage);
    }
  } catch (e) {
    throw ("fetchTheImagesSavedFromMidjourneyResponse error: $e");
  }
}
