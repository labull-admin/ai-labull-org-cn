import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

class DraggableCachedImage extends StatefulWidget {
  final String imageUrl;

  const DraggableCachedImage({super.key, required this.imageUrl});

  @override
  _DraggableCachedImageState createState() => _DraggableCachedImageState();
}

class _DraggableCachedImageState extends State<DraggableCachedImage> {

  void _onDragUpdate(DragUpdateDetails details) {
    setState(() {
    });
  }

  void _onDragEnd(DragEndDetails details) {
    // Save image to the position where it was dropped
    // using the _dragPosition variable
  }

  @override
  Widget build(BuildContext context) {
    return Draggable(
      feedback: cachedImage(widget: widget),
      child: GestureDetector(
        onPanUpdate: _onDragUpdate,
        onPanEnd: _onDragEnd,
        child: cachedImage(widget: widget),
      ),
    );
  }
}

class cachedImage extends StatelessWidget {
  const cachedImage({
    super.key,
    required this.widget,
  });

  final DraggableCachedImage widget;

  @override
  Widget build(BuildContext context) {
    return CachedNetworkImage(
      imageUrl: widget.imageUrl,
      errorWidget: (context, url, error) => const Icon(Icons.error),
      imageBuilder: (context, imageProvider) => Image(
        image: imageProvider,
        fit: BoxFit.contain,
      ),
      progressIndicatorBuilder: (context, url, downloadProgress) =>
          LinearProgressIndicator(value: downloadProgress.progress),
    );
  }
}
