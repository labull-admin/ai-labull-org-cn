import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:midjourneycn/utils/api_utils/webhook_api_utils.dart';
import 'package:midjourneycn/blocs/midjourney_blocs/image_generation_tasks/state_type.dart';
import 'package:midjourneycn/models/image_generation_tasks.dart';
import 'package:midjourneycn/models/user.dart';

part 'image_generation_tasks_event.dart';
part 'image_generation_tasks_state.dart';

class ImageGenerationTasksBloc
    extends Bloc<ImageGenerationTasksEvent, ImageGenerationTasksState> {
  ImageGenerationTasksBloc()
      : super(
            const ImageGenerationTasksUpdateInitial(imageGenerationTasks: [])) {
    on<ImageGenerationTasksFetchNextPageOfTasksEvent>(
        _onImageGenerationTasksFetchNextPageOfTasksEvent);
    on<ImageGenerationTasksCreateTaskEvent>(
        _onImageGenerationTasksCreateTaskEvent);
  }

  void _onImageGenerationTasksFetchNextPageOfTasksEvent(
      ImageGenerationTasksFetchNextPageOfTasksEvent event,
      Emitter<ImageGenerationTasksState> emit) async {
    try {
      emit(ImageGenerationTasksUpdateInitial(
          imageGenerationTasks: state.imageGenerationTasks));
      emit(ImageGenerationTasksUpdateLoadingState(
          imageGenerationTasks: state.imageGenerationTasks));
      //get the page number of the next page to load
      int pageToLoad = state.imageGenerationTasks.length ~/ 10 + 1;
      List<ImageGenerationTask> imageGenerationTasks =
          await fetchThePageOfImageGenerationTasks(
              userJwtAccessToken: event.user.jwtAccessToken!,
              pageToLoad: pageToLoad);
      emit(ImageGenerationTasksUpdateSuccessState(imageGenerationTasks: [
        ...state.imageGenerationTasks,
        ...imageGenerationTasks
      ]));
    } catch (e) {
      emit(ImageGenerationTasksUpdateFailureState(
          error: e.toString(),
          imageGenerationTasks: state.imageGenerationTasks));
    }
  }

  void _onImageGenerationTasksCreateTaskEvent(
      ImageGenerationTasksCreateTaskEvent event,
      Emitter<ImageGenerationTasksState> emit) async {
    try {
      emit(ImageGenerationTasksUpdateInitial(
          imageGenerationTasks: state.imageGenerationTasks));
      emit(ImageGenerationTasksUpdateLoadingState(
          imageGenerationTasks: state.imageGenerationTasks));

      ImageGenerationTask imageGenerationTasks =
          await createImageGenerationTask(
              userJwtAccessToken: event.user.jwtAccessToken!,
              content: event.content);
      //update latest tasks with union method
      emit(ImageGenerationTasksUpdateSuccessState(imageGenerationTasks: [
        imageGenerationTasks,
        ...state.imageGenerationTasks
      ]));
    } catch (e) {
      emit(ImageGenerationTasksUpdateFailureState(
          error: e.toString(),
          imageGenerationTasks: state.imageGenerationTasks));
    }
  }
}
