const String authNotLogedInStateType = "authNotLogedInStateType";
const String authLogedInStateType = "authLogedInStateType";

const String authLoginInitialStateType = "authLoginInitialStateType";
const String authLoginLoadingStateType = "authLoginLoadingStateType";
const String authLoginSuccessStateType = "authLoginSuccessStateType";
const String authLoginFailureStateType = "authLoginFailureStateType";

const String authLogoutInitialStateType = "authLogoutInitialStateType";
const String authLogoutLoadingStateType = "authLogoutLoadingStateType";
const String authLogoutSuccessStateType = "authLogoutSuccessStateType";
const String authLogoutFailureStateType = "authLogoutFailureStateType";
