class ImageProcessStatus {
  static const String notStarted = 'not_started';
  static const String initializing = 'initializing';

  static const String progressing = 'progressing';
  static const String failed = 'failed';
  static const String successful = 'successful';

  Map<String, String> imageProcessStatus = {
    notStarted: 'not_started',
    initializing: 'initializing',
    successful: 'successful',
    progressing: 'progressing',
    failed: 'failed',
  };
}
