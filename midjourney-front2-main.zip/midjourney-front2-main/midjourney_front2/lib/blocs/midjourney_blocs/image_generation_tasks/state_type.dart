const String imageGenerationTasksUpdateInitialStateType =
    "imageGenerationTasksUpdateInitialStateType";
const String imageGenerationTasksUpdateLoadingStateType =
    "imageGenerationTasksUpdateLoadingStateType";
const String imageGenerationTasksUpdateSuccessStateType =
    "imageGenerationTasksUpdateSuccessStateType";
const String imageGenerationTasksUpdateFailureStateType =
    "imageGenerationTasksUpdateFailureStateType";
