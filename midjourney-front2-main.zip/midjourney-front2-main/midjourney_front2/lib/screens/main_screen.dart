import 'package:flutter/material.dart';
import 'package:midjourneycn/blocs/bloc_exports.dart';
import 'package:midjourneycn/screens/gallery_screen/gallery_screen.dart';
import 'package:midjourneycn/screens/login_screen.dart';
import 'package:midjourneycn/screens/setting_screen/setting_screen.dart';
import 'package:midjourneycn/screens/tasks_screen/tasks_screen.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthBloc, AuthState>(
      builder: (context, state) {
        return Directionality(
          textDirection: TextDirection.ltr,
          child: MaterialApp(
              home: state is AuthLogedInState == false
                  ? LoginScreen()
                  : Scaffold(
                      body: IndexedStack(
                        index: _selectedIndex,
                        children: const [
                          TasksScreen(),
                          GalleryScreen(),
                          SettingScreen(),
                        ],
                      ),
                      bottomNavigationBar: BottomNavigationBar(
                        items: const <BottomNavigationBarItem>[
                          BottomNavigationBarItem(
                            icon: Icon(Icons.attractions_sharp),
                            label: 'tasks',
                          ),
                          BottomNavigationBarItem(
                            icon: Icon(Icons.image_rounded),
                            label: 'gallery',
                          ),
                          BottomNavigationBarItem(
                            icon: Icon(Icons.settings),
                            label: 'setting',
                          ),
                        ],
                        currentIndex: _selectedIndex,
                        onTap: (index) {
                          setState(() {
                            _selectedIndex = index;
                          });
                        },
                      ),
                    )),
        );
      },
    );
  }
}
