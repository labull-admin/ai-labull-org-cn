import 'dart:convert';
import 'package:http/http.dart' as http;

import 'package:midjourneycn/models/user.dart';

const String midjourneyCnBackendUrl =
    "http://webhook-project-dev.ap-east-1.elasticbeanstalk.com";

const String coreLoginApiUrl = "$midjourneyCnBackendUrl/core/login/";
const String midjourneyInitialResponseApiUrl =
    "$midjourneyCnBackendUrl/midjourney/midjourneyinitialresponse/";
const String midjourneyInitialResponseImagineApiUrl =
    "$midjourneyCnBackendUrl/midjourney/midjourneyinitialresponseimagine/";
const String midjourneyInitialResponseButtonsApiUrl =
    "$midjourneyCnBackendUrl/midjourney/midjourneyinitialresponsebuttons/";
const String imageGenerationTaskApiUrl =
    "$midjourneyCnBackendUrl/midjourney/imagegenerationtask/";
const String midjourneyResponseToWebhookApiUrl =
    "$midjourneyCnBackendUrl/midjourney/midjourneyresponsetowebhook/";
const String imagessavedFromMidjourneyResponseApiUrl =
    "$midjourneyCnBackendUrl/midjourney/imagessavedfrommidjourneyresponse/";

//get a midjourneyInitialResponse
Future<Map<String, dynamic>> getAMidjourneyInitialResponse({
  required User user,
  required int midjourneyInitialResponsePk,
}) async {
  try {
    final response = await http.get(
      Uri.parse(
          '$midjourneyInitialResponseApiUrl${midjourneyInitialResponsePk.toString()}/'),
      headers: {
        'Authorization': 'JWT ${user.jwtAccessToken}',
      },
    );
    final data = jsonDecode(utf8.decode(response.bodyBytes));
    ;
    if (response.statusCode == 200) {
      return data;
    } else {
      String errorMessage =
          'Failed to get a midjourneyInitialResponse: response status code is ${response.statusCode}';
      data.containsKey('detail')
          ? errorMessage += ': ${data['detail']}'
          : errorMessage;
      throw Exception(errorMessage);
    }
  } catch (e) {
    throw ('getAMidjourneyInitialResponse error: $e');
  }
}

//delete the ImageGenerationTask
Future<List<dynamic>> deleteTheImageGenerationTask(
    {required User user, required int imageGenerationTaskPk}) async {
  try {
    final response = await http.delete(
      Uri.parse('$imageGenerationTaskApiUrl$imageGenerationTaskPk/'),
      headers: {
        'Authorization': 'JWT ${user.jwtAccessToken}',
      },
    );
    final data = jsonDecode(utf8.decode(response.bodyBytes));
    if (response.statusCode == 202) {
      String message = '${response.statusCode} delete successful';
      data.containsKey('detail') ? message += ': ${data['detail']}' : message;
      return data;
    } else {
      String errorMessage =
          'Failed to delete tasks: response status code is ${response.statusCode}';
      data.containsKey('detail')
          ? errorMessage += ': ${data['detail']}'
          : errorMessage;
      throw Exception(errorMessage);
    }
  } catch (e) {
    throw ('deleteTheImageGenerationTask error: $e');
  }
}

//get the ImagesSavedFromMidjourneyResponse
Future<Map<String, dynamic>> getTheImagesSavedFromMidjourneyResponse(
    {required User user,
    required int imageSavedFromMidjourneyResponsePk}) async {
  try {
    final response = await http.get(
      Uri.parse(
          "$imagessavedFromMidjourneyResponseApiUrl${imageSavedFromMidjourneyResponsePk.toString()}/"),
      headers: {
        'Authorization': 'JWT ${user.jwtAccessToken}',
      },
    );
    final data = jsonDecode(utf8.decode(response.bodyBytes));
    if (response.statusCode == 200) {
      return data;
    } else {
      String errorMessage =
          'Failed to fetch image from the backend: response status code is ${response.statusCode}';
      data.containsKey('detail')
          ? errorMessage += ': ${data['detail']}'
          : errorMessage;
      throw Exception(errorMessage);
    }
  } catch (e) {
    throw ('getTheImagesSavedFromMidjourneyResponse error: $e');
  }
}

Future<Map<String, dynamic>> getTheMidjourneyResponseToWebhook(
    {required User user, required int midjourneyResponseToWebhookPk}) async {
  try {
    final response = await http.get(
      Uri.parse(
          "$midjourneyResponseToWebhookApiUrl${midjourneyResponseToWebhookPk.toString()}/"),
      headers: {
        'Authorization': 'JWT ${user.jwtAccessToken}',
      },
    );
    final data = jsonDecode(utf8.decode(response.bodyBytes));
    if (response.statusCode == 200) {
      return data;
    } else {
      String errorMessage =
          'Failed to fetch MidjourneyResponseToWebhook from the backend: response status code is ${response.statusCode}';
      data.containsKey('detail')
          ? errorMessage += ': ${data['detail']}'
          : errorMessage;
      throw Exception(errorMessage);
    }
  } catch (e) {
    throw ('getTheMidjourneyResponseToWebhook error: $e');
  }
}

//post midjourneyImagineApi
Future<Map<String, dynamic>> postMidjourneyImagineApi(
    {required User user, required String content}) async {
  try {
    final response = await http.post(
      Uri.parse(midjourneyInitialResponseImagineApiUrl),
      headers: {
        'Authorization': 'JWT ${user.jwtAccessToken}',
      },
      body: {
        'content': content,
      },
    );
    final data = jsonDecode(utf8.decode(response.bodyBytes));
    if (response.statusCode == 201) {
      return data;
    } else {
      String errorMessage =
          'Failed to post midjourneyImagineApi: response status code is ${response.statusCode}';
      data.containsKey('detail')
          ? errorMessage += ': ${data['detail']}'
          : errorMessage;
      throw Exception(errorMessage);
    }
  } catch (e) {
    throw ('postMidjourneyImagineApi error: $e');
  }
}

//post midjourneyImagineApi
Future<Map<String, dynamic>> postMidjourneyButtonApi(
    {required User user,
    required String buttonMessageId,
    required String buttonLabel}) async {
  try {
    final response = await http.post(
      Uri.parse(midjourneyInitialResponseButtonsApiUrl),
      headers: {
        'Authorization': 'JWT ${user.jwtAccessToken}',
      },
      body: {
        "buttonMessageId": buttonMessageId,
        "button": buttonLabel,
        "ref": "",
        "webhookOverride": ""
      },
    );
    final data = jsonDecode(utf8.decode(response.bodyBytes));
    if (response.statusCode == 201) {
      return data;
    } else {
      String errorMessage =
          'Failed to post midjourneyButtonApi: response status code is ${response.statusCode}';
      data.containsKey('detail')
          ? errorMessage += ': ${data['detail']}'
          : errorMessage;
      throw Exception(errorMessage);
    }
  } catch (e) {
    throw ('postMidjourneyButtonApi error: $e');
  }
}
