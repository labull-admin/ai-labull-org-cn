import 'package:flutter/material.dart';
import 'package:midjourneycn/screens/tasks_screen/image_to_image_screen.dart';
import 'package:midjourneycn/screens/tasks_screen/prompt_image_generation_screen/prompt_image_generation_screen.dart';

class TasksScreen extends StatefulWidget {
  const TasksScreen({Key? key}) : super(key: key);

  @override
  State<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends State<TasksScreen> {
  int _selectedIndex = 0;

  final List<Map<String, dynamic>> tasks = [
    {
      'title': 'Prompt Image Generation',
      'screen': PromptImageGenerationScreen(),
    },
    {
      'title': 'Img to Img',
      'screen': ImageToImageScreen(),
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        DropdownButton(
          value: _selectedIndex,
          items: tasks
              .asMap()
              .entries
              .map((entry) => DropdownMenuItem(
                    value: entry.key,
                    child: Text(entry.value['title']),
                  ))
              .toList(),
          onChanged: (value) {
            setState(() {
              _selectedIndex = value as int;
            });
          },
        ),
        Expanded(
          flex: 2,
          child: IndexedStack(
            index: _selectedIndex,
            children: tasks.map((task) => (task['screen'] as Widget)).toList(),
          ),
        ),
      ],
    );
  }
}
