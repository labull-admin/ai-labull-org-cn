// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:equatable/equatable.dart';

class User extends Equatable {
  String name;
  String password;
  String? jwtAccessToken;
  String? jwtRefreshToken;

  User({
    required this.name,
    required this.password,
    this.jwtAccessToken,
    this.jwtRefreshToken,
  });

  User copyWith({
    String? name,
    String? password,
    String? jwtAccessToken,
    String? jwtRefreshToken,
  }) {
    return User(
      name: name ?? this.name,
      password: password ?? this.password,
      jwtAccessToken: jwtAccessToken ?? this.jwtAccessToken,
      jwtRefreshToken: jwtRefreshToken ?? this.jwtRefreshToken,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'name': name,
      'password': password,
      'jwtAccessToken': jwtAccessToken,
      'jwtRefreshToken': jwtRefreshToken,
    };
  }

  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      name: map['name'] as String,
      password: map['password'] as String,
      jwtAccessToken: map['jwtAccessToken'] as String?,
      jwtRefreshToken: map['jwtRefreshToken'] as String?,
    );
  }
  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'password': password,
      'jwtAccessToken': jwtAccessToken,
      'jwtRefreshToken': jwtRefreshToken,
    };
  }

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      name: json['name'] as String,
      password: json['password'] as String,
      jwtAccessToken: json['jwtAccessToken'] as String?,
      jwtRefreshToken: json['jwtRefreshToken'] as String?,
    );
  }
  @override
  List<Object?> get props => [
        name,
        password,
        jwtAccessToken,
        jwtRefreshToken,
      ];
}
