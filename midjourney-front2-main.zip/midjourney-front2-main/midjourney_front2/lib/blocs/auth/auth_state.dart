part of 'auth_bloc.dart';

sealed class AuthState extends Equatable {
  final User? user;
  final String? error;
  const AuthState({this.user, this.error});

  @override
  List<Object?> get props => [
        user,
        error,
      ];
}

final class AuthNotLogedInState extends AuthState {
  const AuthNotLogedInState();
  static Map<String, dynamic> toMap(AuthNotLogedInState state) => {
        'type': authNotLogedInStateType,
      };
  static AuthNotLogedInState fromMap(Map<String, dynamic> map) =>
      const AuthNotLogedInState();
}

final class AuthLogedInState extends AuthState {
  const AuthLogedInState({
    required User user,
  }) : super(
          user: user,
        );
  static Map<String, dynamic> toMap(AuthLogedInState state) => {
        'type': authLogedInStateType,
        'user': state.user,
      };
  static AuthLogedInState fromMap(Map<String, dynamic> map) =>
      AuthLogedInState(user: User.fromJson(map['user']));
}

final class AuthLoginInitialState extends AuthState {
  const AuthLoginInitialState({
    required User user,
  }) : super(
          user: user,
        );
  static Map<String, dynamic> toMap(AuthLoginInitialState state) => {
        'type': authLoginInitialStateType,
        'user': state.user,
      };
  static AuthLoginInitialState fromMap(Map<String, dynamic> map) =>
      AuthLoginInitialState(user: User.fromJson(map['user']));
}

final class AuthLoginLoadingState extends AuthState {
  const AuthLoginLoadingState();
  static Map<String, dynamic> toMap(AuthLoginLoadingState state) => {
        'type': authLoginLoadingStateType,
      };
  static AuthLoginLoadingState fromMap(Map<String, dynamic> map) =>
      const AuthLoginLoadingState();
}

final class AuthLoginSuccessState extends AuthState {
  const AuthLoginSuccessState();
  static Map<String, dynamic> toMap(AuthLoginSuccessState state) => {
        'type': authLoginSuccessStateType,
      };
  static AuthLoginSuccessState fromMap(Map<String, dynamic> map) =>
      const AuthLoginSuccessState();
}

final class AuthLoginFailureState extends AuthState {
  const AuthLoginFailureState({required String error})
      : super(
          error: error,
        );
  static Map<String, dynamic> toMap(AuthLoginFailureState state) => {
        'type': authLoginFailureStateType,
        'error': state.error,
      };

  static AuthLoginFailureState fromMap(Map<String, dynamic> map) =>
      AuthLoginFailureState(
        error: map['error'] as String,
      );
}

final class AuthLogoutInitialState extends AuthState {
  const AuthLogoutInitialState();
  static Map<String, dynamic> toMap(AuthLogoutInitialState state) => {
        'type': authLogoutInitialStateType,
      };
  static AuthLogoutInitialState fromMap(Map<String, dynamic> map) =>
      const AuthLogoutInitialState();
}

final class AuthLogoutLoadingState extends AuthState {
  const AuthLogoutLoadingState();
  static Map<String, dynamic> toMap(AuthLogoutLoadingState state) => {
        'type': authLogoutLoadingStateType,
      };
  static AuthLogoutLoadingState fromMap(Map<String, dynamic> map) =>
      const AuthLogoutLoadingState();
}

final class AuthLogoutSuccessState extends AuthState {
  const AuthLogoutSuccessState();
  static Map<String, dynamic> toMap(AuthLogoutSuccessState state) => {
        'type': authLogoutSuccessStateType,
      };
  static AuthLogoutSuccessState fromMap(Map<String, dynamic> map) =>
      const AuthLogoutSuccessState();
}

final class AuthLogoutFailureState extends AuthState {
  const AuthLogoutFailureState({required String error})
      : super(
          error: error,
        );
  static Map<String, dynamic> toMap(AuthLogoutFailureState state) => {
        'type': authLogoutFailureStateType,
        'error': state.error,
      };

  static AuthLogoutFailureState fromMap(Map<String, dynamic> map) =>
      AuthLogoutFailureState(
        error: map['error'] as String,
      );
}
